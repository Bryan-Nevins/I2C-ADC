
/*  Notes on I2C_adc_ADs1115_A:  adapted from UART and other projects
 want to Tx & Rx data to ads1115 from msp430fr6989
         P1.7/SCL <--------> SCL0    only an output since launchpad is Master
         P1.6/SDA <--------> SDA0     an input or an output

 */

// include files:
#include <msp430.h>
#include <stdint.h>
// #include "usi_i2c.h"  // different hardware--maybe don't use it

//  #defines    //
#define ENABLE_PINS 0xFFFE // Required to use inputs and outputs
#define GREEN_LED 0x0080 // P9.7 is the green LED
#define RED_LED = 0x0001   // P1.0 = red led

#define ADC_address = 0b1001000  // ads1115 pg 11, addr pin grounded
// #define ADC_address = 0x90  // ads1115 pg 11, addr pin grounded

// function protos  //
void Setup_Clocks(void) ; // Setup clocks for synch operation
void led_pins_setup() ;  // set up pins and leds (ports)

void init_i2c();
void I2C_pins_setup (void) ; //  setup pins for I2C
void singleBytewrite();


//Global variables
char Uflag = 0;  // uart ISR flag
int Urx  = 0 ;  // Uart recieve number
//
int main(void)
{
 //   int i=0,  Nindex = 0 ,  Rarray[200]  ;
	WDTCTL = WDTPW | WDTHOLD; // Stop WDT
    led_pins_setup() ;  // set up pins and leds (ports)
   Setup_Clocks(); // Setup clocks for synch communication
   I2C_pins_setup()  ;  //  setup I2C pins P1.6, P1.7
   init_i2c();
   P9OUT = P9OUT ^ GREEN_LED;// Toggle green LED
    P1OUT = BIT0; // Turn on red LED
 //  P1OUT = RED_LED  ; // Turn on red LED
    GIE; // general interrupt enable


while(1)      //  just toggle led for now
    {
    P9OUT = P9OUT ^ GREEN_LED;// Toggle green LED
    __delay_cycles(2e4);   // 10 turn ons in 5s: --> 8E6 Mhz clock
    singleBytewrite();      // starts function to write 1 byte to slave register
    }

}// end main()

// function definitions:  led_pins, clocks,

void led_pins_setup(void)  // set up pins and leds (ports)
{
    /// enable pins for adc and led
    // PM5CTL0 = ENABLE_PINS; // Required to use inputs and outputs"
    PM5CTL0 &= ~LOCKLPM5;                   // Disables high-impedance mode for FRAM memory  from https://e2e.ti.com/support/microcontrollers/msp430/f/166/p/524735/1909491?pi318617=2
    P1DIR = BIT0 ; //  P1.0:    red led as output
    P1OUT = 0x00; // Red LED initially off
    P9DIR = GREEN_LED; // Set green LED as an output
    P9OUT = 0x00  ;   // green led initially off  ;

}   // end led_pins_setup function

void I2C_pins_setup (void)
{

    P1SEL0 |= BIT6 | BIT7;                    // Assign I2C function USCI_B0  P1.7 = clk p1.6 = data   from TI i2c_10.c
    // Disable the GPIO power-on default high-impedance mode to activate
    // previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

//   P1DIR = 0xFF ;  // debug p1.6,1.7, set as outputs
   //     P1OUT = 0x00 ;  //  debug:   force pins low
  //  P1SEL0 |= BIT6 + BIT7;                      // init P1.6 and 7, primary not I/O  : TI site nasa camera
  //  P1SEL1 &= ~BIT6 + ~BIT7;
}

void Setup_Clocks(void)   //  8-2-2017:  8Mhz system clock
{
    CSCTL0_H = CSKEY >> 8; // Unlock CS registers

    /*    1-4Mhz clock frequencies

   // CSCTL1 = DCOFSEL_0; // Set DCO to 1MHz
   // CSCTL1 = DCOFSEL_1; // Set DCO to 2.67MHz
   //  CSCTL1 = DCOFSEL_3; // Set DCO to 4 MHz
   //  CSCTL1 = DCOFSEL_3; // Set DCO to 4 MHz
     * comment 2
     */

     CSCTL1 = DCOFSEL_6; // Set DCO to 8 MHz works  loopback works good.


/*
  *     // 16Mhz operation: Loopback has glitch at 16Mhz clock
 //    FRCTL0  = FRCTLPW | NWAITS_1 ; // = 0xA5 ; // for clock>8Mhz unlock FR control register  NWAITS = 1 ; //for 16Mhz  CS low for 3us 16 bit spi
// "lock FR register" never works, not used in TI code examples
    // FRCTL0  = 0x9600  | NWAITS_1 ;   // try to lock frctl
  //  CSCTL1 = DCOFSEL_4 + DCORSEL; // Set DCO to 16 MHz,  need wait state---adjust frctl0
  *
  */

     CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1; // CLOCK DIVIDERS Do NOT change any frequencies (1 = divide by 1)
     //    CSCTL3 = DIVA__2 | DIVS__1 | DIVM__1; // Aclock now 16khz

     CSCTL2 = 0 | SELS__DCOCLK | SELM__DCOCLK;    // SCLK =DCO, MCLK = DCO, no need for ACLK here
      // CSCTL2 = SELA__LFXTCLK | SELS__DCOCLK | SELM__DCOCLK;   // ACLK: 32.768kHz  SMCLK will use DCO (1MHz)   MCLK will use DCO (1MHz)

     CSCTL4 = CSCTL4 & (LFXTOFF); // disable  32.768kHz crystal
 /* no need for LF oscillator
     CSCTL4 = CSCTL4 & (~LFXTOFF); // Enable 32.768kHz crystal
    do // Wait here until 32.768kHz
    { // clock is ready
        CSCTL5 = CSCTL5 & (~LFXTOFFG); // Clear 32.768kHz fault flags
        SFRIFG1 = SFRIFG1 & (~OFIFG); // Clear 32.768kHz fault flags
    }
    while (SFRIFG1&OFIFG); // Test 32.768kHz oscillator-- fault flag---move this line before do?
     */

    CSCTL0_H = 0; // Lock CS registers
} // end "setup_clocks" function

//*********************************************************************************


void init_i2c() {   // code from TI2: https://e2e.ti.com/support/microcontrollers/msp430/f/166/t/550170
   UCB0CTLW0 |= UCSWRST;            // Enable SW reset.  eUSCI_Bx Control Word Register 0  FG 26.4.1
 //  UCB0CTLW0 |= UCMST | UCMODE_3 | UCSYNC;  //original code: multi-Master, master mode, I2C, synchronous mode, use SMCLK, 7 bit addr = default
   UCB0CTLW0 |= UCMST + UCMODE_3 + UCSSEL_3 ; // feb 2017 version  multi-Master: master mode, I2C, use SMCLK

 //  UCB0BRW = 10;    // fSCL = SMCLK/10 = ~100kHz  (settings for 1Mhz clk)
   UCB0BRW = 80;    // fSCL = SMCLK/80 = ~100kHz
//   UCB0CTLW1 = UCASTP_2; // automatic STOP assertion

  // UCB0TBCNT = 0x07; // TX 7 bytes of data
   // UCB0TBCNT = 2;         //I've tried commenting and un-commenting the  byte count, but it doesn't seem to make a difference

 //  UCB0I2CSA = 0x006C;     //  original code: Slave address  (0x6C for write, 0x6D for read)  FG p657, 26.4.14
   UCB0I2CSA = 0b1001000 ; // ADC_address defined above.  see FG 26.4.14

   UCB0CTLW0 &= ~UCSWRST;                   // set eUSCI_B to Clear SW reset, resume operation

   UCB0IE |= UCTXIE0 | UCRXIE0 | UCNACKIE | UCBCNTIE;       // Enable Transmit interrupt, receive interrupt, the NACK interrupt, and UCB
   GIE; // general interrupt enable
}

void singleBytewrite() {   // from TI2: https://e2e.ti.com/support/microcontrollers/msp430/f/166/t/550170
      UCB0CTLW0 |= UCTR;
     UCB0CTLW0 |= UCTXSTT;                       // I2C start condition

 //   while ((UCB0IFG & UCTXIFG0) == 0);      //Wait until flag set (this is set when the start condition has been generated and data is ready to be written to the buffer)
    UCB0TXBUF = 0x90;                         // sends slave address (For some reason this also has to be specified in addition to the UCB0I2CSA register
   //  while(UCB0CTLW0 & UCTXSTT);         // gets stuck here! UCTXSTT flag is cleared as soon as the complete address is sent

 //    P1OUT = P1OUT ^ (BIT0 + BIT6 + BIT7 ); // debug p1.6, p1.7  Toggle P1.0---red led and bits 6,7
    P1OUT = P1OUT ^ BIT0; // Toggle  Red led


    UCB0TXBUF = 0x0030;
    UCB0TXBUF = 0x002A;
}
